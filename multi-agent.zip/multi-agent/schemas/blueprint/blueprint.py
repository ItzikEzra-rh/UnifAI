# from pydantic import BaseModel
# from typing import List, Union
#
# from schemas.llm.openai_config import OpenAIConfig
# from schemas.llm.llama_stack_config import LlamaStackConfig
# from schemas.llm.openai_config import OpenAIConfig
#
# from schemas.tools.tool_config import (
#     CalculatorConfig, WeatherConfig,
#     HTTPToolConfig, MCPToolConfig, WebSearchConfig
# )
# from schemas.retriever.retriever_config import (
#     SlackRetrieverConfig, JiraRetrieverConfig, PDFRetrieverConfig
# )
# from schemas.agents.mock_agent_config import MockAgentConfig
# from .step import StepConfig
#
# # Union types for top-level lists
# ToolConfig = Union[
#     CalculatorConfig, WeatherConfig,
#     HTTPToolConfig, MCPToolConfig, WebSearchConfig
# ]
# RetrieverConfig = Union[
#     SlackRetrieverConfig, JiraRetrieverConfig, PDFRetrieverConfig
# ]
#
# LLMConfig = Union[OpenAIConfig, LlamaStackConfig]
# class Blueprint(BaseModel):
#     """
#     Full blueprint schema, including dynamic component definitions
#     and an ordered list of steps.
#     """
#     llms: List[LLMConfig] = []
#     tools: List[ToolConfig] = []
#     retrievers: List[RetrieverConfig] = []
#     agents: List[MockAgentConfig] = []
#     plan: List[StepConfig]
