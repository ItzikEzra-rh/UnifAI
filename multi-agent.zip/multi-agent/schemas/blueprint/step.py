from pydantic import BaseModel
from typing import List, Union
from schemas.nodes.base_node import BaseNodeConfig


class StepConfig(BaseModel):
    """
    Defines a single step in the blueprint plan.
    """
    name: str
    after: Union[str, List[str]] = None
    node: Union[str, BaseNodeConfig]
