from pydantic import BaseModel, HttpUrl
from typing import Literal, Optional, Dict

class LLMConfig(BaseModel):
    """
    Pydantic schema for configuring a Language Model (LLM) backend.

    Attributes:
        name: A unique identifier for this LLM instance.
        type: The type of LLM (e.g., 'openai', 'mock', 'llamastack').
        base_url: Optional HTTP endpoint for LLM API (OpenAI etc.).
        api_key: Optional API key or token for authentication.
        model: Optional model name/version (e.g. 'gpt-4').
        endpoint: Optional alternative endpoint (for LlamaStack).
        headers: Optional HTTP headers to include on each request.
        temperature: Sampling temperature for generation (0.0–1.0).
    """
    name: str
    type: Literal["openai", "mock", "llamastack"]
    base_url: Optional[HttpUrl] = None
    api_key: Optional[str] = None
    model: Optional[str] = None
    endpoint: Optional[HttpUrl] = None
    headers: Optional[Dict[str, str]] = {}
    temperature: Optional[float] = 0.7
