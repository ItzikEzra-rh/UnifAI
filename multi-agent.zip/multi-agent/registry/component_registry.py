# registry/component_registry.py

from threading import RLock
from typing import Any, Dict, Union


class ComponentNotFoundError(KeyError):
    """Raised when a requested component is not found in the registry."""
    pass


class ComponentRegistry:
    """
    Central, thread-safe registry for all *static* components in the system:
    - Nodes (workflow steps)
    - Agents (data‐source wrappers)
    - LLMs (language model clients)
    - Tools (utility functions)
    - Conditions (branching logic)

    Responsibilities:
    1. Allow registering and retrieving components by name.
    2. Provide safe existence checks (`has_*`) for UI or preflight logic.
    3. Offer a generic interface (`get`, `has`) for YAML/DSL parsing.
    """

    def __init__(self) -> None:
        # Private dicts for each category
        self._nodes: Dict[str, Any] = {}
        self._agents: Dict[str, Any] = {}
        self._llms: Dict[str, Any] = {}
        self._tools: Dict[str, Any] = {}
        self._conditions: Dict[str, Any] = {}

        # Reentrant lock to allow thread-safe register/get
        self._lock = RLock()

    # ---- Node registry ----

    def register_node(self, name: str, node: Any) -> None:
        """
        Register a workflow node class or factory under a unique name.

        :param name: Unique identifier for this node.
        :param node: A callable or class implementing the node logic.
        """
        if not name:
            raise ValueError("Node name must be a non-empty string.")
        with self._lock:
            self._nodes[name] = node

    def has_node(self, name: str) -> bool:
        """Return True if a node with this name is registered."""
        with self._lock:
            return name in self._nodes

    def get_node(self, name: str) -> Any:
        """
        Retrieve a previously registered node.

        :raises ComponentNotFoundError: if no node under this name exists.
        """
        with self._lock:
            try:
                return self._nodes[name]
            except KeyError:
                raise ComponentNotFoundError(f"Node '{name}' not found in registry.")

    # ---- Agent registry ----

    def register_agent(self, name: str, agent: Any) -> None:
        """
        Register an agent instance or factory.

        :param name: Unique identifier for this agent.
        :param agent: An object implementing get_answer or similar.
        """
        if not name:
            raise ValueError("Agent name must be a non-empty string.")
        with self._lock:
            self._agents[name] = agent

    def has_agent(self, name: str) -> bool:
        """Return True if an agent with this name is registered."""
        with self._lock:
            return name in self._agents

    def get_agent(self, name: str) -> Any:
        """
        Retrieve a previously registered agent.

        :raises ComponentNotFoundError: if no agent under this name exists.
        """
        with self._lock:
            try:
                return self._agents[name]
            except KeyError:
                raise ComponentNotFoundError(f"Agent '{name}' not found in registry.")

    # ---- LLM registry ----

    def register_llm(self, name: str, llm: Any) -> None:
        """
        Register an LLM client or wrapper.

        :param name: Unique identifier for this LLM.
        :param llm: An object implementing the LLM interface.
        """
        if not name:
            raise ValueError("LLM name must be a non-empty string.")
        with self._lock:
            self._llms[name] = llm

    def has_llm(self, name: str) -> bool:
        """Return True if an LLM with this name is registered."""
        with self._lock:
            return name in self._llms

    def get_llm(self, name: str) -> Any:
        """
        Retrieve a previously registered LLM.

        :raises ComponentNotFoundError: if no LLM under this name exists.
        """
        with self._lock:
            try:
                return self._llms[name]
            except KeyError:
                raise ComponentNotFoundError(f"LLM '{name}' not found in registry.")

    # ---- Tool registry ----

    def register_tool(self, name: str, tool: Any) -> None:
        """
        Register a tool instance or factory.

        :param name: Unique identifier for this tool.
        :param tool: An object implementing the tool interface.
        """
        if not name:
            raise ValueError("Tool name must be a non-empty string.")
        with self._lock:
            self._tools[name] = tool

    def has_tool(self, name: str) -> bool:
        """Return True if a tool with this name is registered."""
        with self._lock:
            return name in self._tools

    def get_tool(self, name: str) -> Any:
        """
        Retrieve a previously registered tool.

        :raises ComponentNotFoundError: if no tool under this name exists.
        """
        with self._lock:
            try:
                return self._tools[name]
            except KeyError:
                raise ComponentNotFoundError(f"Tool '{name}' not found in registry.")

    # ---- Condition registry ----

    def register_condition(self, name: str, func: Any) -> None:
        """
        Register a branching condition function.

        :param name: Unique identifier for this condition.
        :param func: Callable(state) -> bool or branch key.
        """
        if not name:
            raise ValueError("Condition name must be a non-empty string.")
        with self._lock:
            self._conditions[name] = func

    def has_condition(self, name: str) -> bool:
        """Return True if a condition with this name is registered."""
        with self._lock:
            return name in self._conditions

    def get_condition(self, name: str) -> Any:
        """
        Retrieve a previously registered condition function.

        :raises ComponentNotFoundError: if no condition under this name exists.
        """
        with self._lock:
            try:
                return self._conditions[name]
            except KeyError:
                raise ComponentNotFoundError(f"Condition '{name}' not found in registry.")

    # ---- Generic interface ----

    def has(self, component_type: str, name: str) -> bool:
        """
        Generic check for existence of any component type.

        :param component_type: One of "node", "agent", "llm", "tool", "condition".
        """
        lookup = {
            "node": self.has_node,
            "agent": self.has_agent,
            "llm": self.has_llm,
            "tool": self.has_tool,
            "condition": self.has_condition,
        }
        try:
            return lookup[component_type](name)
        except KeyError:
            raise ValueError(f"Unknown component type '{component_type}'")

    def get(self, component_type: str, name: str) -> Any:
        """
        Generic retrieval of any component type.

        :param component_type: One of "node", "agent", "llm", "tool", "condition".
        """
        getters = {
            "node": self.get_node,
            "agent": self.get_agent,
            "llm": self.get_llm,
            "tool": self.get_tool,
            "condition": self.get_condition,
        }
        try:
            return getters[component_type](name)
        except KeyError:
            raise ValueError(f"Unknown component type '{component_type}'")
