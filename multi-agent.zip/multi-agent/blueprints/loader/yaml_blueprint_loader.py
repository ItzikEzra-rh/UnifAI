# blueprints/yaml_blueprint_loader.py

import yaml
from .base_blueprint_loader import BaseBlueprintLoader


# from schemas.blueprint_schema import BlueprintSpec
# from plugins.exceptions import InvalidBlueprintError


class YAMLBlueprintLoader(BaseBlueprintLoader):
    """
    Loads a YAML blueprint and validates against BlueprintSpec.
    """

    def load(self, path: str):
        try:
            with open(path, "r", encoding="utf-8") as f:
                raw = yaml.safe_load(f)
                return raw
        except Exception as e:
            raise Exception(f"Failed to load YAML: {e}")
