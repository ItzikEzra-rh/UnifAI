from registry.component_registry import ComponentRegistry
from graph.blueprint_loader import BlueprintLoader
from engine.langgraph_builder import LangGraphBuilder
from state.runtime_state import RuntimeState
from logs.in_memory_logger import InMemoryLogger


def setup_registry():
    from nodes import user_question, coordinator, aggregator, discussion, critic, final_answer
    from llms.mock_llm import MockLLM
    from agents.slack_agent import SlackAgent

    registry = ComponentRegistry()
    registry.register_node("user_question", user_question.UserQuestionNode())
    registry.register_node("final_answer", final_answer.FinalAnswerNode())
    registry.register_llm("mock", MockLLM())
    registry.register_agent("slack", SlackAgent())
    return registry


def run_graph():
    registry = setup_registry()
    blueprint = BlueprintLoader(registry).build_from_code()
    graph = LangGraphBuilder().build(blueprint)

    runtime = RuntimeState(plan=blueprint, graph=graph, logger=InMemoryLogger())

    initial_state = {
        "user_input": "What happened on Slack this week?",
        "messages": [],
        "log": [],
    }

    result = runtime.graph.invoke(initial_state)
    print("Final result:\n", result.get("final_output"))


if __name__ == "__main__":
    run_graph()
