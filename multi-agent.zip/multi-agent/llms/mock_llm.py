from llms.base_llm import BaseLLM

class MockLLM(BaseLLM):
    def chat(self, messages: list[dict], stream: bool = False) -> str:
        return "[MOCK RESPONSE] Hello! You said: " + messages[-1]["content"]

    def name(self) -> str:
        return "mock"
